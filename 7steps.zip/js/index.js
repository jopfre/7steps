
$(document).ready(function(){

	MicroModal.init();

  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    // nav:true,
    responsive:{
        0:{
            items:1
        },
    }
})

});